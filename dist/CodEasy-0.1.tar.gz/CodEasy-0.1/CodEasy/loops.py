def for_loop(start=0, end=10, step=1, variable_name="i"):
    code = f"for {variable_name} in range({start}, {end}, {step}):\n    # Write your code here\n    pass"
    return code

def while_loop(condition="True"):
    code = f"while {condition}:\n    # Write your code here\n    pass"
    return code
